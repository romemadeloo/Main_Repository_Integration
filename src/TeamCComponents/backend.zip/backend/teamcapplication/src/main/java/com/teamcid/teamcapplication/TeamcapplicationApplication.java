package com.teamcid.teamcapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamcapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamcapplicationApplication.class, args);
	}

}
