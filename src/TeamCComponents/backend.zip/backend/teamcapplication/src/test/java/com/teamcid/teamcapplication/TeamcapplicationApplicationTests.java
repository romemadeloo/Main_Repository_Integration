package com.teamcid.teamcapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamcapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
